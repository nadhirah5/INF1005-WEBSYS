 <footer class="container">
    <p>Copyright &copy; 2023 Wackdonalds Pte. Ltd.</p>
</footer>
