


<section class="flex">

    <a href="index.php" class="logo"><i class="fas fa-utensils"></i> Wackdonalds </a>

    <nav class="navbar">
        <a class="active" href="index.php">home</a>
        <a href="#dishes">dishes</a>
        <a href="#about">about us</a> 
        <!--under about section, will link to, learn more about us-->

        <a href="menu.php">menu</a>
        <!--<a href="#review">review</a>-->
        <a href="#order">Reservation</a>
        <a href="aboutus.html">more</a>

    </nav>

    <div class="icons">
        <i class="fas fa-bars" id="menu-bars"></i>
        <!--<i class="fas fa-search" id="search-icon"></i>-->
        <a href="profile.php" class="fas fa-user"></a>
        <a href="#" class="fas fa-heart"></a>
        <a href="#" class="fas fa-shopping-cart"></a>
    </div>

</section>